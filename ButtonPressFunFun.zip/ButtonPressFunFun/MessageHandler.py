def serialize(key, value):
    return f"{key},{value}"


def serialize_colors(colors):
    message = "COLORS:"

    for num in colors:
        message += f"{num},"

    return message[0:len(message) - 1]


def parse(message):
    return message.split(",")
