from commands.Commands import *
import MessageHandler
import Constants
from connection.Connection import ConnectionManager
from gameplay.Sequence import GenerateSequence


# Callbacks
def on_incoming_message(message):
    print("Incoming message:", message)
    try:
        data = MessageHandler.parse(message)
        key = int(data[0])
        value = int(data[1])

        if key == Constants.GAME_START:
            on_game_start()
        elif key == Constants.GAME_OVER:
            on_game_over()
        elif key == Constants.NEXT_LEVEL:
            if value == 1:
                on_game_start()
            else:
                print("Queuing for level:", value)
                command_queue.add_command(PlayLevelCommand(value, connectionManager,
                                                           sequence_generator, on_level_result))
        else:
            print(message)
    except:
        print("Wrong message format")


def on_level_result(result):
    connectionManager.send_message(MessageHandler.serialize(result, Constants.NOTHING))


def on_game_start():
    game_state.game_over = False
    command_queue.add_command(PlayLevelCommand(1, connectionManager, sequence_generator, on_level_result))


def on_game_over():
    game_state.game_over = True


# State
class GameState:
    def __init__(self):
        self.quit = False
        self.game_over = True


# Global variables
command_queue = CommandQueue()
game_state = GameState()
sequence_generator = GenerateSequence()
connectionManager = ConnectionManager(on_incoming_message)


# Game logic
def play_game():
    while not game_state.game_over:
        """ Listen for game input """
        print("Inside play_game()")
        command_queue.execute_commands()


while not game_state.quit:
    """ Listen for game start """
    play_game()