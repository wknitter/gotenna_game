import abc
import time
import Constants
from gameplay.Input import InputManager
from connection.Connection import ConnectionManager
import MessageHandler
from threading import Semaphore


class Command(metaclass=abc.ABCMeta):
    """
    The command interface that declares a method (execute) for a particular
    action.
    """
    @abc.abstractmethod
    def execute(self):
        pass


class PlayLevelCommand(Command):

    def __init__(self, current_level, connection_manager, sequence_generator, level_result_callback):
        self.current_level = current_level
        self.connection_manager = connection_manager
        self.sequence_generator = sequence_generator
        self.level_result_callback = level_result_callback
        self.semaphore = Semaphore()

    def execute(self):
        button_sequence = self.sequence_generator.get_sequence()
        self.connection_manager.send_message(MessageHandler.serialize_colors(button_sequence))
        InputManager(button_sequence, self.on_button_response)
        self.semaphore.acquire()

    def on_button_response(self, result):
        print(result)
        self.sequence_generator.set_sequence_add()
        self.level_result_callback(result)
        self.semaphore.release()


class CommandQueue:

    def __init__(self):
        self.commands = []

    def add_command(self, command):
        self.commands.append(command)

    def execute_commands(self):
        for command in self.commands:
            print("Executing command")
            command.execute()

        self.commands.clear()
