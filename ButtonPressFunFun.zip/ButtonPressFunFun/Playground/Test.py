from gameplay.Sequence import GenerateSequence

generator = GenerateSequence()

message = "COLORS:"

for num in generator.sequence:
    message += f"{num},"
message = message[0:len(message) - 1]

print(message)