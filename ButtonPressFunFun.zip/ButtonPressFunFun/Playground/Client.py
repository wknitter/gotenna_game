import socket

HOST = "127.0.1"
PORT = 65432

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

message = input("Enter message: ")

while (message != "Quit"):
    s.send(bytes(message, "utf-8"))
    message = input("Enter message: ")
