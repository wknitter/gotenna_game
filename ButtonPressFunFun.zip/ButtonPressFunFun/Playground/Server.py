import socket

HOST = "127.0.1"
PORT = 65432

connection_established = False
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen()
clientsocket, address = s.accept()
while True:
    if (not connection_established):
        print(f"Connection from {address} has been established.")
        connection_established = True

    message = clientsocket.recv(1024)
    print(message.decode("utf-8"))
