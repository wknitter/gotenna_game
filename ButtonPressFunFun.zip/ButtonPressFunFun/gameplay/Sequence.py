import random


class GenerateSequence:

    start = 0
    end = 3
    sequence = []
    number_colors = [4, 27, 22, 5]

    def rand(self, start, end, num):
        res = self.sequence
        for j in range(num):
            res.append(self.number_colors[random.randint(start, end)])
        return res

    def __init__(self):
        self.sequence = self.rand(self.start, self.end, 3)

    def set_sequence_add(self):
        self.sequence.append(self.number_colors[random.randint(self.start, self.end)])

    def get_sequence(self):
        return self.sequence

