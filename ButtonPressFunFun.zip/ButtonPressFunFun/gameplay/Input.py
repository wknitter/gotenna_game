import RPi.GPIO as GPIO
from time import sleep
from Constants import *
import threading


class InputManager:

    def __init__(self, sequence, on_button_callback):
        self.sequence = sequence
        self.on_button_callback = on_button_callback
        self.current_index = 0
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(RED_BUTTON, GPIO.IN)
        GPIO.setup(BLUE_BUTTON, GPIO.IN)
        GPIO.setup(GREEN_BUTTON, GPIO.IN)
        GPIO.setup(YELLOW_BUTTON, GPIO.IN)
        thread = threading.Thread(target=self.listen_for_input(), args=())
        thread.start()

    def listen_for_input(self):
        while self.current_index < len(self.sequence):
            if GPIO.input(RED_BUTTON):
                print("red")
                if self.sequence[self.current_index] != RED_BUTTON:
                    self.on_button_callback(LEVEL_FAIL)
                while GPIO.input(RED_BUTTON):
                    # wait for button to release
                    sleep(0.001)
                self.current_index += 1
            elif GPIO.input(BLUE_BUTTON):
                print("blue")
                if self.sequence[self.current_index] != BLUE_BUTTON:
                    self.on_button_callback(LEVEL_FAIL)
                while GPIO.input(BLUE_BUTTON):
                    # wait for button to release
                    sleep(0.001)
            elif GPIO.input(GREEN_BUTTON):
                print("green")
                if self.sequence[self.current_index] != GREEN_BUTTON:
                    self.on_button_callback(LEVEL_FAIL)
                while GPIO.input(GREEN_BUTTON):
                    # wait for button to release
                    sleep(0.001)
            elif GPIO.input(YELLOW_BUTTON):
                print("yellow")
                if self.sequence[self.current_index] != YELLOW_BUTTON:
                    self.on_button_callback(LEVEL_FAIL)
                while GPIO.input(YELLOW_BUTTON):
                    # wait for button to release
                    sleep(0.001)
            else:
                print("Waiting...")
                sleep(0.1)

        self.on_button_callback(LEVEL_PASS)
